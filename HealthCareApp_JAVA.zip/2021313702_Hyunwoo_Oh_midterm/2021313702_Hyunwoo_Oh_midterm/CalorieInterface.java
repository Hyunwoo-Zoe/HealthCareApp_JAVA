
// Interface with the abstract method that would be implemented
public interface CalorieInterface {
    void calculateCalories(); 
}


public abstract class Exercise implements CalorieInterface 
{
    public double consumedCalories; // Declare to store the consumed calories for each exercise
    public abstract void calculateCalories(); // Remain empty for implementation in each exercise type class
    
    // getter & setter function for field
    public double getConsumedCalories() 
    { 
        return consumedCalories;
    }

    public void setConsumedCalories(double consumedCalories) 
    {
        this.consumedCalories = consumedCalories;
    }

   
}

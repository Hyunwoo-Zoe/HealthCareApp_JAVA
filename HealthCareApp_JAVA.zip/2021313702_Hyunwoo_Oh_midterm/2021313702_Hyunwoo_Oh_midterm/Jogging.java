
public class Jogging extends Exercise 
{
	public Course course; // Declare to store the Course Class object

	// Constructor to set the Course in parameter to the field
    public Jogging(Course course) 
    {
        this.setCourse(course);
    }
   // Getter & Setter Function for the field
    public Course getCourse() 
    {
        return course;
    }

    public void setCourse(Course course) 
    { 
        this.course = course;
    }
    
    // Implement the the abstract method according to Jogging Class calorie computation way
    public void calculateCalories() 
    {
        consumedCalories = course.getCaloriePerDistance() * course.getDistance();
    }
}


public class Match 
{
	public double caloriePerSet; // Declare to store the Calorie Consumed Per Set
	public int numSets;  // Declare to store the number of Sets

	// Getter & Setter Functions for the fields
    public double getCaloriePerSet() 
    { 
        return caloriePerSet;
    }

    public void setCaloriePerSet(double caloriePerSet) 
    { 
        this.caloriePerSet = caloriePerSet;
    }

    public int getNumSets() 
    {
        return numSets;
    }

    public void setNumSets(int numSets) 
    {
        this.numSets = numSets;
    }
}

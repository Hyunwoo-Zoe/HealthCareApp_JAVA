
public class Badminton extends Exercise 
{
	public Course course; // Declare to store the Course Class object
	public Match match;  // Declare to store the Match Class object
	public int numMatches; // Declare to store the number of Matches
	
   // Constructor to set all the fields using setter functions
    public Badminton(Course course, Match match, int numMatches) 
    {
        this.setCourse(course);
        this.setMatch(match);
        this.setNumMatches(numMatches);
    }
    
    // Getter & Setter Functions for the fields
    public Course getCourse() 
    { 
        return course;
    }

    public void setCourse(Course course) 
    { 
        this.course = course;
    }

    public Match getMatch() 
    { 
        return match;
    }

    public void setMatch(Match match) 
    {
        this.match = match;
    }

    public int getNumMatches() 
    { 
        return numMatches;
    }

    public void setNumMatches(int numMatches) 
    {
        this.numMatches = numMatches;
    }

    // Implement the the abstract method according to Badminton Class calorie computation way
    public void calculateCalories() 
    {
        consumedCalories = (course.getCaloriePerDistance() * course.getDistance()) + (match.getCaloriePerSet() * match.getNumSets() * numMatches);
    }
}
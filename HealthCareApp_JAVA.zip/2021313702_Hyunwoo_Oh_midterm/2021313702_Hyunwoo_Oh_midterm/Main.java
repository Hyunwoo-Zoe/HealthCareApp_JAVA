
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends JFrame 
{
    private enum State {CHOOSE_FITNESS, ENTER_NUMBERS, YESORNO} // Declare Enum to define different states in the application
    private final Dimension BUTTON_SIZE = new Dimension(124, 28); // Set constant for the standard button size
    private Exercise[] exercises = new Exercise[100]; // Declare Exercise class type array to store different exercises
    private int numExercises = -1; // Declare to store the number of total Exercises
    private String input = ""; // Declare to store the User Input
    private State state = State.CHOOSE_FITNESS; // Declare to determine the current state

    private JLabel lblLogoImage; // Declare to show image of logo
    private JLabel lblLogoText; // Declare to show text of logo 
    private JButton[] btnExercise = new JButton[4]; // Declare JButton Array for exercise options
    private JTextArea txtPrintOut; // Set text area for output display
    private JButton Yes_Button; // Yes button for confirmation
    private JButton No_Button; // No button for rejection
    private JButton[] btnNumber = new JButton[10]; // Numeric buttons (0-9)
    private JButton[] btnInputCtrl = new JButton[3]; // Control buttons for input management

    public Main() {
            // Initialize logo components
            lblLogoImage = new JLabel(new ImageIcon(getClass().getResource("/assets/fitness_planner_logo.png"))); // load image to the logo part
            lblLogoText = new JLabel("Fitness Planner", SwingConstants.CENTER);
            lblLogoText.setFont(new Font("Serif", Font.BOLD, 20)); // Set font for the logo text

            // Initialize exercise buttons with respective images and text
            btnExercise[0] = new JButton("Swimming", new ImageIcon(getClass().getResource("/assets/swimming.png")));
            btnExercise[1] = new JButton("Jogging", new ImageIcon(getClass().getResource("/assets/jogging.png")));
            btnExercise[2] = new JButton("Tennis", new ImageIcon(getClass().getResource("/assets/tennis.png")));
            btnExercise[3] = new JButton("Badminton", new ImageIcon(getClass().getResource("/assets/badminton.png")));

            // Set the width of all exercise buttons to match the width of the Badminton button (Set to all same width)
            Dimension badmintonSize = btnExercise[3].getPreferredSize();
            for (JButton btn : btnExercise) 
            {
                btn.setPreferredSize(new Dimension(badmintonSize.width, btn.getPreferredSize().height));
                btn.setMaximumSize(new Dimension(badmintonSize.width, btn.getMaximumSize().height));
                btn.setMinimumSize(new Dimension(badmintonSize.width, btn.getMinimumSize().height));
            }

            // Set up the output text area
            txtPrintOut = new JTextArea("Choose Exercise (from left menu):");
            txtPrintOut.setEditable(false); // Make output text area non-editable
            txtPrintOut.setBorder(BorderFactory.createEmptyBorder()); // Remove border from text area

            // Set Yes/No buttons to same size
            Dimension yesNoButtonSize = new Dimension(80, 30); // Declare Dimension object for Yes/No button and put texts and load images
            Yes_Button = new JButton("Yes", new ImageIcon(getClass().getResource("/assets/enterSmall.png")));
            No_Button = new JButton("No", new ImageIcon(getClass().getResource("/assets/cancelSmall.png"))); 

            Yes_Button.setPreferredSize(yesNoButtonSize); // Set size for Yes button
            Yes_Button.setMaximumSize(yesNoButtonSize);
            Yes_Button.setMinimumSize(yesNoButtonSize);

            No_Button.setPreferredSize(yesNoButtonSize); // Set size for No button
            No_Button.setMaximumSize(yesNoButtonSize);
            No_Button.setMinimumSize(yesNoButtonSize);

            // Initialize number buttons (0-9)
            for (int i = 0; i < 10; i++) {
                String imagePath = "/assets/" + i + ".png"; // Declare to store the image path for each button
                btnNumber[i] = new JButton(new ImageIcon(getClass().getResource(imagePath))); // Load the image to each number button
            }

            // Initialize Cancel, Clear, Enter buttons with image and label
            btnInputCtrl[0] = new JButton("CANCEL", new ImageIcon(getClass().getResource("/assets/cancel.png")));
            btnInputCtrl[1] = new JButton("CLEAR", new ImageIcon(getClass().getResource("/assets/clear.png")));
            btnInputCtrl[2] = new JButton("ENTER", new ImageIcon(getClass().getResource("/assets/enter.png")));

            // Add event listeners to buttons
            addExerciseListeners(); // Set listeners for 4 exercise buttons
            addNumberListeners(); // Set listeners for numeric buttons
            addControlListeners(); // Set listeners for three control buttons

            setupLayout(); // Layout setup for GUI components

            setTitle("Fitness Planner"); // Set window title
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Set default close operation
            setSize(600, 800); // Set window size
            setVisible(true); // Display the frame
       
    }

    // Set listeners for exercise buttons
    private void addExerciseListeners() 
    {
        for (int i = 0; i < 4; i++) 
        {
            btnExercise[i].addActionListener(new ActionListener() 
            {
                public void actionPerformed(ActionEvent e) {
                    if (state != State.CHOOSE_FITNESS) return; // Check if state is in selection
                    state = State.ENTER_NUMBERS; // Set state to enter numbers

                    JButton tempButton = (JButton) e.getSource(); // Get button source
                    String exerciseName = tempButton.getText().toLowerCase(); // Get exercise name
                    numExercises++; // Increment exercise count

                    // Add Exercise class to exercises array depending on the exerciseName
                    switch (exerciseName) {
                        case "swimming":
                            txtPrintOut.setText("You choose Swimming.\nEnter Calories Per Distance (kcal / km):");
                            exercises[numExercises] = new Swimming(new Course());
                            break;
                        case "jogging":
                            txtPrintOut.setText("You choose Jogging.\nEnter Calories Per Distance (kcal / km):");
                            exercises[numExercises] = new Jogging(new Course());
                            break;
                        case "tennis":
                            txtPrintOut.setText("You choose Tennis.\nEnter Number of Matches:");
                            exercises[numExercises] = new Tennis(new Match(), -1);
                            break;
                        case "badminton":
                            txtPrintOut.setText("You choose Badminton.\nEnter Number of Matches:");
                            exercises[numExercises] = new Badminton(new Course(), new Match(), -1);
                            break;
                        default:
                            numExercises--; // Subtract count by 1 if there is no match
                            break;
                    }
                }
            });
        }
    }

    // Set listeners for number buttons (0-9)
    private void addNumberListeners() 
    {
        for (int i = 0; i < 10; i++) 
        {
            final int number = i; // Declare final number for lambda expression
            btnNumber[i].addActionListener(e -> {
                if (state != State.ENTER_NUMBERS) return; // Only process if in ENTER_NUMBERS state
                txtPrintOut.setText(txtPrintOut.getText() + number); // Append number selected on display
                input += number; // Add number to input string
            });
        }
    }

    // Set listeners for control buttons (CANCEL, CLEAR, ENTER)
    private void addControlListeners() 
    {
        btnInputCtrl[0].addActionListener(e -> resetPlan()); // Reset the whole plan 

        btnInputCtrl[1].addActionListener(e -> { // Clear the current written input 
            if (state == State.ENTER_NUMBERS) {
                txtPrintOut.setText(txtPrintOut.getText().replaceAll(input, ""));
                input = "";
            }
        });

        btnInputCtrl[2].addActionListener(e -> processInput()); // Process the input

        // Set listener for Yes button 
        Yes_Button.addActionListener(e -> {
            if (state == State.YESORNO) 
            {
                state = State.CHOOSE_FITNESS; // Return to CHOOSE_FITNESS state
                txtPrintOut.setText("Choose Exercise (from left menu): "); // Display the text for the fitness selection
            }
        });

        // Set listener for No button
        No_Button.addActionListener(e -> {
            if (state == State.YESORNO) {
                double totalCalories = 0; // Declare to store the total calories
                StringBuilder result = new StringBuilder(); // Declare StringBuilder object to print the output text
                for (int i = 0; i <= numExercises; i++) {
                    result.append("Exercise ").append(i + 1).append(": ")
                          .append(exercises[i].getClass().getSimpleName()).append("\n")
                          .append("Consumed Calories: ").append(String.format("%.2f", exercises[i].getConsumedCalories())).append(" kcal\n");
                    totalCalories += exercises[i].getConsumedCalories(); // Sum all the calories of exercises stored in array
                }
                result.append("=========================================\n")
                      .append("Total Consumed Calories: ").append(String.format("%.2f", totalCalories)).append(" kcal");
                txtPrintOut.setText(result.toString()); // Show the final results in output
            }
        });
    }

    // Process input considering current exercise type and input from user
    private void processInput() {
        // Only continue if the current state is ENTER_NUMBERS
        if (state != State.ENTER_NUMBERS) return;

        // Get the current exercise being processed
        Exercise currentExercise = exercises[numExercises]; 
        switch (currentExercise.getClass().getSimpleName()) {
            
            case "Swimming":
                // Cast the current exercise to the Swimming class
                Swimming tempSwimming = (Swimming) currentExercise; 
                if (tempSwimming.getCourse().getCaloriePerDistance() == 0) {
                    // If calories per distance is not set, set it using the current input
                    tempSwimming.getCourse().setCaloriePerDistance(Double.parseDouble(input));
                    input = ""; // Clear the input
                    txtPrintOut.setText("Enter distance (in km): "); // Prompt user for distance input
                } else {
                    // If calories per distance is already set, set the distance using the input
                    tempSwimming.getCourse().setDistance(Double.parseDouble(input));
                    input = ""; // Clear the input
                    tempSwimming.calculateCalories(); // Calculate calories based on distance and calories per distance
                    txtPrintOut.setText("Add more exercise? (Yes/No)"); // Prompt user to add another exercise
                    state = State.YESORNO; // Change state to YESORNO for user confirmation
                }
                break;

            case "Jogging":
                // Cast the current exercise to the Jogging class
                Jogging tempJogging = (Jogging) currentExercise;
                if (tempJogging.getCourse().getCaloriePerDistance() == 0) {
                    // If calories per distance is not set, set it using the current input
                    tempJogging.getCourse().setCaloriePerDistance(Double.parseDouble(input));
                    input = ""; // Clear the input
                    txtPrintOut.setText("Enter distance (in km): "); // Prompt user for distance input
                } else {
                    // If calories per distance is already set, set the distance using the input
                    tempJogging.getCourse().setDistance(Double.parseDouble(input));
                    input = ""; // Clear the input
                    tempJogging.calculateCalories(); // Calculate calories based on distance and calories per distance
                    txtPrintOut.setText("Add more exercise? (Yes/No)"); // Prompt user to add another exercise
                    state = State.YESORNO; // Change state to YESORNO for user confirmation
                }
                break;

            case "Tennis":
                // Cast the current exercise to the Tennis class
                Tennis tempTennis = (Tennis) currentExercise;
                if (tempTennis.getNumMatches() == -1) {
                    // If the number of matches is not set, set it using the current input
                    tempTennis.setNumMatches(Integer.parseInt(input));
                    input = ""; // Clear the input
                    txtPrintOut.setText("Enter calories per set (kcal / set): "); // Prompt user for calories per set input
                } else if (tempTennis.getMatch().getCaloriePerSet() == 0) {
                    // If calories per set is not set, set it using the current input
                    tempTennis.getMatch().setCaloriePerSet(Double.parseDouble(input));
                    input = ""; // Clear the input
                    txtPrintOut.setText("Enter number of sets: "); // Prompt user for number of sets input
                } else {
                    // If all values are set, set the number of sets and calculate calories
                    tempTennis.getMatch().setNumSets(Integer.parseInt(input));
                    input = ""; // Clear the input
                    tempTennis.calculateCalories(); // Calculate calories based on matches, calories per set, and sets
                    txtPrintOut.setText("Add more exercise? (Yes/No)"); // Prompt user to add another exercise
                    state = State.YESORNO; // Change state to YESORNO for user confirmation
                }
                break;

            case "Badminton":
                // Cast the current exercise to the Badminton class
                Badminton tempBadminton = (Badminton) currentExercise;
                if (tempBadminton.getNumMatches() == -1) {
                    // If the number of matches is not set, set it using the current input
                    tempBadminton.setNumMatches(Integer.parseInt(input));
                    input = ""; // Clear the input
                    txtPrintOut.setText("Enter calories per set (kcal / set): "); // Prompt user for calories per set input
                } else if (tempBadminton.getMatch().getCaloriePerSet() == 0) {
                    // If calories per set is not set, set it using the current input
                    tempBadminton.getMatch().setCaloriePerSet(Double.parseDouble(input));
                    input = ""; // Clear the input
                    txtPrintOut.setText("Enter number of sets: "); // Prompt user for number of sets input
                } else {
                    // If all values are set, set the number of sets and calculate calories
                    tempBadminton.getMatch().setNumSets(Integer.parseInt(input));
                    input = ""; // Clear the input
                    tempBadminton.calculateCalories(); // Calculate calories based on matches, calories per set, and sets
                    txtPrintOut.setText("Add more exercise? (Yes/No)"); // Prompt user to add another exercise
                    state = State.YESORNO; // Change state to YESORNO for user confirmation
                }
                break;
        }
    }



    // Reset the plan and clear the display
    private void resetPlan() 
    {
        exercises = new Exercise[100]; // Reset exercise array
        numExercises = -1; // Reset the number of Exercises
        txtPrintOut.setText("Cancelled!\n New plan:\nChoose Exercise (from left menu): "); // Display the text for the reset
        state = State.CHOOSE_FITNESS; // Reset state to CHOOSE_FITNESS
        input = ""; // Clear the input
    }

    // Layout setup for the panels and components
    private void setupLayout() 
    {
    	Yes_Button.setMaximumSize(BUTTON_SIZE); // Set the maximum size for the Yes button
    	Yes_Button.setPreferredSize(BUTTON_SIZE); // Set the preferred size for the Yes button
    	No_Button.setMaximumSize(BUTTON_SIZE); // Set the maximum size for the No button
    	btnInputCtrl[1].setMaximumSize(btnInputCtrl[0].getPreferredSize()); // Set the maximum size for the CLEAR button to match the CANCEL button size
    	btnInputCtrl[2].setMaximumSize(btnInputCtrl[0].getPreferredSize()); // Set the maximum size for the ENTER button to match the CANCEL button size

    	lblLogoText.setFont(new Font("Serif", Font.BOLD, 20)); // Set the font and style for the logo text
    	txtPrintOut.setBorder(BorderFactory.createEmptyBorder()); // Remove the border from the output text area
    	txtPrintOut.setEditable(false); // Make the output text area non-editable
    	JPanel pnlContent = new JPanel(); // Create the main content panel
    	JPanel pnlNorth = new JPanel(); // Create the top panel
    	JPanel pnlTitleImg = new JPanel(); // Create the logo image panel
    	JPanel pnlTitleText = new JPanel(); // Create the logo text panel
    	JPanel pnlWest = new JPanel(); // Create the left panel
    	JPanel pnlCenter = new JPanel(); // Create the center panel
    	JPanel pnlEast = new JPanel(); // Create the right panel
    	JPanel pnlSouth = new JPanel(); // Create the bottom panel
    	JPanel pnlSouthWest = new JPanel(); // Create the bottom-left panel
    	JPanel pnlSouthEast = new JPanel(); // Create the bottom-right panel
    	JPanel pnlSouthCenter = new JPanel(); // Create the bottom-center panel

    	// Set layout managers
    	pnlNorth.setLayout(new BoxLayout(pnlNorth, BoxLayout.Y_AXIS)); // Set vertical layout for the top panel
    	pnlTitleImg.setLayout(new BoxLayout(pnlTitleImg, BoxLayout.X_AXIS)); // Set horizontal layout for the logo image panel
    	pnlTitleText.setLayout(new BoxLayout(pnlTitleText, BoxLayout.X_AXIS)); // Set horizontal layout for the logo text panel
    	pnlWest.setLayout(new BoxLayout(pnlWest, BoxLayout.Y_AXIS)); // Set vertical layout for the left panel
    	pnlCenter.setLayout(new BoxLayout(pnlCenter, BoxLayout.Y_AXIS)); // Set vertical layout for the center panel
    	pnlEast.setLayout(new BoxLayout(pnlEast, BoxLayout.Y_AXIS)); // Set vertical layout for the right panel
    	pnlSouth.setLayout(new BorderLayout()); // Set BorderLayout for the bottom panel
    	pnlSouthCenter.setLayout(new GridLayout(4, 3)); // Set 4x3 grid layout for the bottom-center panel
    	pnlSouthEast.setLayout(new BoxLayout(pnlSouthEast, BoxLayout.Y_AXIS)); // Set vertical layout for the bottom-right panel

    	// Add components to the container
    	pnlTitleImg.add(Box.createHorizontalGlue()); // Add horizontal glue for spacing
    	pnlTitleImg.add(lblLogoImage); // Add the logo image label to the panel
    	pnlTitleImg.add(Box.createHorizontalGlue()); // Add horizontal glue for spacing
    	pnlTitleText.add(Box.createVerticalGlue()); // Add vertical glue for spacing
    	pnlTitleText.add(lblLogoText); // Add the logo text label to the panel
    	pnlTitleText.add(Box.createVerticalGlue()); // Add vertical glue for spacing
    	pnlWest.add(Box.createVerticalGlue()); // Add vertical glue for spacing
    	for(int i = 0; i < 4; i++)
    	    pnlWest.add(btnExercise[i]); // Add exercise buttons to the left panel
    	pnlWest.add(Box.createVerticalGlue()); // Add vertical glue for spacing
    	pnlCenter.add(txtPrintOut); // Add the output text area to the center panel
    	pnlEast.add(Box.createVerticalGlue()); // Add vertical glue for spacing
    	pnlEast.add(Yes_Button); // Add the Yes button to the right panel
    	pnlEast.add(No_Button); // Add the No button to the right panel
    	pnlEast.add(Box.createVerticalGlue()); // Add vertical glue for spacing
    	pnlSouthWest.add(Box.createHorizontalStrut(124)); // Add horizontal spacing to the bottom-left panel
    	for (int i = 1; i < 10; i++)
    	    pnlSouthCenter.add(btnNumber[i]); // Add number buttons (1-9) to the bottom-center panel
    	pnlSouthCenter.add(new JLabel()); // Add an empty label for layout alignment
    	pnlSouthCenter.add(btnNumber[0]); // Add the '0' button to the bottom-center panel
    	for (int i = 0; i < 3; i++)
    	    pnlSouthEast.add(btnInputCtrl[i]); // Add control buttons (CANCEL, CLEAR, ENTER) to the bottom-right panel

    	// Combine partial containers
    	pnlNorth.add(pnlTitleImg); // Add the logo image panel to the top panel
    	pnlNorth.add(pnlTitleText); // Add the logo text panel to the top panel
    	pnlSouth.add(pnlSouthWest, BorderLayout.WEST); // Add the bottom-left panel to the bottom panel (WEST)
    	pnlSouth.add(pnlSouthCenter, BorderLayout.CENTER); // Add the bottom-center panel to the bottom panel (CENTER)
    	pnlSouth.add(pnlSouthEast, BorderLayout.EAST); // Add the bottom-right panel to the bottom panel (EAST)

    	// Combine main containers
    	pnlContent.setLayout(new BorderLayout()); // Set BorderLayout for the main content panel
    	pnlContent.add(pnlNorth, BorderLayout.NORTH); // Add the top panel to the main content panel (NORTH)
    	pnlContent.add(pnlWest, BorderLayout.WEST); // Add the left panel to the main content panel (WEST)
    	pnlContent.add(pnlCenter, BorderLayout.CENTER); // Add the center panel to the main content panel (CENTER)
    	pnlContent.add(pnlEast, BorderLayout.EAST); // Add the right panel to the main content panel (EAST)
    	pnlContent.add(pnlSouth, BorderLayout.SOUTH); // Add the bottom panel to the main content panel (SOUTH)

    	// Add padding around the main content panel
    	pnlContent.setBorder(BorderFactory.createEmptyBorder(40, 10, 20, 10)); // Set empty border with top, left, bottom, right padding

    	// Show the frame
    	add(pnlContent); // Add the main content panel to the frame
    	setTitle("Fitness Planner"); // Set the window title
    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Set the default close operation
    	setSize(600, 800); // Set the window size
    	setVisible(true); // Display the frame

	}
    

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Main(); // Begin the Control Flow with Main constructor
            }
        });
    }
}


public class Tennis extends Exercise 
{
    public Match match; // Declare to store the Match Class object
    public int numMatches; // Declare to store the number of Matches

    // Constructor to set all the fields using setter functions
    public Tennis(Match match, int numMatches) 
    {
        this.setMatch(match);
        this.setNumMatches(numMatches);
    }
    // Getter & Setter Functions for the fields
    public Match getMatch() 
    { 
        return match;
    }

    public void setMatch(Match match) 
    {
        this.match = match;
    }

    public int getNumMatches() 
    { 
        return numMatches;
    }

    public void setNumMatches(int numMatches) 
    { 
        this.numMatches = numMatches;
    }
     // Implement the the abstract method according to Tennis Class calorie computation way
    public void calculateCalories() 
    {
        consumedCalories = match.getCaloriePerSet() * match.getNumSets() * numMatches;
    }
}


public class Swimming extends Exercise 
{
	public Course course; // Declare to store the Course class object

	// Constructor to set the Course
    public Swimming(Course course) 
    {
        this.setCourse(course);
    }
    // Getter & Setter function for field
    public Course getCourse() 
    { 
        return course;
    }

    public void setCourse(Course course) 
    { 
        this.course = course;
    }

    // Implement the the abstract method according to Swimming Class calorie computation way
    public void calculateCalories() 
    {
        consumedCalories = course.getCaloriePerDistance() * course.getDistance();
    }
}

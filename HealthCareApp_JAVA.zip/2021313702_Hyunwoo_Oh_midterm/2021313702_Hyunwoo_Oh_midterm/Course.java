
public class Course 
{
	public double caloriePerDistance; // Declare to store the Calories Consumed Per Distance
	public double distance; // Declare to store the distance

	// Getter & Setter functions for the fields
    public double getCaloriePerDistance() 
    { 
        return caloriePerDistance;
    }

    public void setCaloriePerDistance(double caloriePerDistance) 
    { 
        this.caloriePerDistance = caloriePerDistance;
    }

    public double getDistance() 
    { 
        return distance;
    }

    public void setDistance(double distance) 
    { 
        this.distance = distance;
    }
}
